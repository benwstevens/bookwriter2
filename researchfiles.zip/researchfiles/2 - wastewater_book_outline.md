# Developing a Wastewater Treatment Plant
## A Complete Chapter-by-Chapter Outline

---

## PART ONE: BEFORE THE FIRST SHOVEL
*History, Politics, Funding, and the Hidden World of Wastewater*

---

### Chapter 1: Nobody Thinks About It Until It Stops Working
**~1,300 words**

**Opener (2–3 paragraphs):**
Analogy from medicine — how the lymphatic system is the body's most critical and least understood system. Nobody goes to a cocktail party and talks about their lymph nodes. But when lymphatic drainage fails, everything fails. Wastewater treatment is the lymphatic system of civilization. Draw the parallel: invisible, essential, and only discussed during catastrophe.

**Section 1: A Very Brief History of Human Waste (4–5 paragraphs)**
- Ancient Rome's Cloaca Maxima — the first engineered sewer
- The Great Stink of London (1858) and how Parliament literally couldn't function because of the Thames
- The germ theory revolution and how it changed infrastructure priorities
- America's early 20th-century approach: dilution as the solution to pollution
- The moment public health and civil engineering merged permanently

**Section 2: The Clean Water Act and Everything That Followed (4–5 paragraphs)**
- 1972: the Clean Water Act as a political earthquake
- How the EPA's creation changed the funding and regulatory landscape overnight
- The massive federal investment of the 1970s–80s in municipal treatment plants
- The slow, quiet crisis: those plants are now 40–50 years old and failing
- The current state of American wastewater infrastructure — a $271 billion gap (EPA estimates)

**Section 3: Why Wastewater Projects Start — The Triggers (4–5 paragraphs)**
- Consent decrees: when the EPA or state regulators force a municipality's hand
- Capacity failures: population growth outpacing plant design
- Permit violations: when effluent quality consistently misses the mark
- Political will: the rare mayor or council that gets ahead of the problem
- The insider truth: most projects are reactive, not proactive. The behind-the-scenes scramble when a consent decree lands.

**Section 4: What a Veteran Knows That a Newcomer Doesn't (4–5 paragraphs)**
- These projects don't start with engineering — they start with politics
- The utility director is often the most important person in the room, not the mayor
- Every community has a "wastewater champion" — someone who's been trying to get this funded for years
- The public doesn't care until rates go up, and then they care enormously
- The emotional weight of the work: these projects protect public health for generations, but the people who make them happen rarely get credit

**Conclusion (1–2 paragraphs):**
Wastewater treatment is civilization's quiet contract with itself. The fact that most people don't know how it works is actually a sign that it's working. But when it breaks — through age, neglect, or politics — the consequences are immediate and visceral.

**Next Chapter Teaser:**
But understanding *why* these projects happen is only half the story. The real complexity begins when a municipality tries to figure out how to pay for one — because the funding landscape for wastewater is unlike anything else in public infrastructure, and the timeline between "we need this" and "we can afford this" can stretch across entire political administrations.

---

### Chapter 2: Follow the Money — How Wastewater Gets Funded
**~1,400 words**

**Opener (2–3 paragraphs):**
Analogy from filmmaking — how a movie's budget determines everything about what ends up on screen. The director may have a vision, but the financier decides the runtime. In wastewater, the funding mechanism doesn't just pay for the plant — it dictates the design, the timeline, the materials, and often the politics of who gets credit.

**Section 1: The Funding Alphabet Soup (4–5 paragraphs)**
- State Revolving Funds (SRFs) — the workhorse of wastewater funding
- USDA Rural Development loans and grants — the lifeline for small communities
- EPA WIFIA loans — for large-scale projects ($20M+)
- Municipal bonds (revenue bonds vs. general obligation) — the traditional route
- The newer players: ARPA funds, Bipartisan Infrastructure Law money, and why they changed everything temporarily

**Section 2: The Timeline Nobody Warns You About (4–5 paragraphs)**
- From "we need a plant" to "we broke ground" is often 7–12 years
- The pre-planning phase: needs assessments, facilities plans, and the preliminary engineering report (PER)
- How funding applications work — the PER as the gateway document
- State agency review cycles and why they take 6–18 months
- The insider truth: you're designing the project to match the funding source, not the other way around. USDA projects look different from SRF projects because the rules are different.

**Section 3: Rate Studies and the Political Third Rail (4–5 paragraphs)**
- Why every wastewater project eventually becomes a conversation about monthly bills
- The rate study: how engineers and financial consultants model what residents will pay
- Affordability thresholds — the EPA's guidance on what percentage of median household income is acceptable
- The political dance: councils that approve the project but won't approve the rate increase
- The behind-the-scenes reality: funding agencies look at rate structures *before* they approve loans. A community unwilling to raise rates is a community that won't get funded.

**Section 4: The Grant Game and Why Small Towns Struggle (4–5 paragraphs)**
- How grant funding actually works — income surveys, median household income, and the poverty threshold
- Why some communities qualify for 75% grant funding and others get 0%
- The consultant's role: grant writers, financial advisors, and the "funding stack"
- How experienced teams layer multiple funding sources into a single project
- The uncomfortable truth: the communities that need the most help often have the least capacity to navigate the application process

**Conclusion (1–2 paragraphs):**
Funding is the invisible architecture of every wastewater project. It shapes timelines, design choices, and political careers. Understanding the money isn't optional — it's the prerequisite for understanding everything that follows.

**Next Chapter Teaser:**
With funding secured — or at least plausibly mapped — the project enters a phase that sounds bureaucratic but is actually one of the most consequential: the environmental review and permitting process. It's where federal agencies, state regulators, endangered species, and local politics collide in ways that can delay a project by years — or kill it entirely.

---

### Chapter 3: Permits, Politics, and the Endangered Mussel
**~1,300 words**

**Opener (2–3 paragraphs):**
Analogy from air traffic control — dozens of agencies, each with authority over a different slice of airspace, all needing to coordinate before a single plane takes off. In wastewater permitting, the agencies don't always coordinate — and the plane sometimes sits on the tarmac for years.

**Section 1: The NPDES Permit — Your Project's Constitution (4–5 paragraphs)**
- What an NPDES (National Pollutant Discharge Elimination System) permit actually is
- How discharge limits are set — receiving water quality, downstream uses, TMDLs
- The difference between technology-based and water-quality-based limits
- Nutrient limits (nitrogen and phosphorus) — the regulatory trend reshaping plant design
- The insider angle: your discharge permit determines your treatment technology. If the permit tightens mid-design, your project scope and cost can change dramatically.

**Section 2: Environmental Reviews — NEPA, SEPA, and the Alphabet (4–5 paragraphs)**
- When federal funding triggers NEPA (National Environmental Policy Act) review
- Environmental Assessments vs. Environmental Impact Statements — the difference matters enormously
- The state-level equivalents and how they layer on top
- Historical and cultural resource reviews — when construction sites intersect with archaeology
- The endangered species problem: how a freshwater mussel or a bat habitat can reshape a $50M project

**Section 3: Land, Easements, and the Neighbors (4–5 paragraphs)**
- Acquiring land for a treatment plant — the process most people underestimate
- Easements for sewer lines, outfall pipes, and access roads
- The NIMBY factor: public meetings, opposition, and the politics of odor
- Buffer zones, setback requirements, and their impact on site selection
- The veteran's perspective: site selection is as much a political decision as a technical one. The "best" site on paper is often the worst site in practice.

**Section 4: The Regulatory Coordination Dance (4–5 paragraphs)**
- How the Army Corps of Engineers, EPA, state DEQ, Fish & Wildlife, and local authorities interact
- Wetland delineation and Section 404 permits
- Floodplain considerations and FEMA coordination
- The timeline implications: permits don't run in parallel as neatly as the schedule suggests
- The thing nobody tells you: the permitting timeline is where projects actually die. Not from opposition — from delay, exhaustion, and political turnover.

**Conclusion (1–2 paragraphs):**
Permitting is where the idealism of "let's build a better plant" meets the friction of democratic governance. It's frustrating, slow, and essential. Every day spent in permitting is a day the existing system continues to degrade.

**Next Chapter Teaser:**
But once permits are in hand and funding is committed, something remarkable happens: the project transitions from the world of policy and politics into the world of engineering. And the first question the design team must answer is deceptively simple — what, exactly, are we building? The answer, it turns out, depends on biology as much as it depends on concrete.

---

## PART TWO: THE DESIGN PROCESS
*Engineering, Architecture, and the Art of Treating What Nobody Wants to Think About*

---

### Chapter 4: How Wastewater Treatment Actually Works
**~1,400 words**

**Opener (2–3 paragraphs):**
Analogy from cooking — specifically, clarifying butter. You're separating what you want from what you don't through a series of progressive steps: heating, skimming, filtering, and settling. Wastewater treatment follows the same logic: preliminary, primary, secondary, and (sometimes) tertiary treatment. Each stage removes a different category of contaminant, and skipping one ruins the next.

**Section 1: Preliminary and Primary Treatment — The Rough Cut (4–5 paragraphs)**
- Influent screening: removing rags, wipes, grit, and debris
- The headworks building — often the most unpleasant space in the entire facility
- Grit removal: why sand and gravel must come out before anything else
- Primary clarifiers: gravity settling, scum removal, and the first major separation
- The scale problem: most people have no idea how much material arrives at a treatment plant daily

**Section 2: Secondary Treatment — Where Biology Does the Work (4–5 paragraphs)**
- The activated sludge process: using bacteria to eat organic material
- Aeration basins, mixed liquor, and the concept of "bugs" doing the work
- Biological nutrient removal (BNR) — nitrogen and phosphorus removal through biological processes
- Alternative technologies: trickling filters, sequencing batch reactors (SBRs), membrane bioreactors (MBRs)
- How the discharge permit drives technology selection — one size does not fit all

**Section 3: Tertiary Treatment and Disinfection — The Polish (4–5 paragraphs)**
- Filtration: sand filters, cloth disk filters, and membrane filtration
- Disinfection methods: chlorine, UV, and ozone — tradeoffs and trends
- Dechlorination: why you sometimes have to remove the disinfectant you just added
- Effluent quality monitoring and compliance
- The emerging challenges: PFAS, pharmaceuticals, and microplastics — the contaminants the regulations haven't fully caught up with

**Section 4: What Happens to the Solids (4–5 paragraphs)**
- Sludge handling: thickening, digestion, and dewatering
- Anaerobic digestion and biogas — turning waste into energy
- Land application, landfilling, and incineration — disposal options and their politics
- The odor question: why solids handling is the #1 source of neighborhood complaints
- The insider perspective: solids handling is often an afterthought in design but becomes the dominant operational headache

**Conclusion (1–2 paragraphs):**
Understanding the process is essential because every design decision, every piece of equipment, every building on the site exists to serve one of these stages. The treatment train is the spine of the project — everything else is built around it.

**Next Chapter Teaser:**
Now that you understand what the plant does, the question becomes: who designs it? The answer is a team of specialists, each with a different lens on the same problem — and the civil engineer who leads that team has to hold a vision that balances hydraulics, topography, and a budget that never seems large enough.

---

### Chapter 5: The Civil Engineer's Canvas — Site Design and Hydraulics
**~1,300 words**

**Opener (2–3 paragraphs):**
Analogy from urban planning — how Frederick Law Olmsted designed Central Park not as a static picture but as a system of flows: water, people, carriages, all moving through the landscape on carefully graded paths. A wastewater treatment plant site works the same way — except the primary "flow" is gravity, and getting the grades wrong means pumping costs that haunt the owner for decades.

**Section 1: Site Layout and the Hydraulic Profile (4–5 paragraphs)**
- The hydraulic profile: how water moves through the plant by gravity (or by force)
- Why the site's topography dictates the arrangement of treatment units
- The concept of hydraulic head and why every foot of elevation matters
- How experienced civil engineers minimize pumping by using natural grade
- The balancing act: compact footprints vs. operational access and future expansion

**Section 2: Grading, Drainage, and Earthwork (4–5 paragraphs)**
- Cut-and-fill balancing — keeping earthwork costs under control
- Stormwater management on a treatment plant site (the irony is not lost on anyone)
- Flood protection: when the plant that treats water is threatened by water
- Access roads, truck turning radii, and the forgotten logistics of chemical delivery
- Underground utilities: the maze beneath the surface that nobody sees on the site plan

**Section 3: Piping — The Circulatory System (4–5 paragraphs)**
- Process piping vs. utility piping vs. site piping — different systems, different materials
- Pipe sizing: the consequences of getting it wrong (hint: you can't easily fix it later)
- Valving, flow control, and redundancy — why everything has a bypass
- The coordination challenge: piping drawings touch every discipline
- The veteran's insight: more projects have cost overruns from piping conflicts than from any other single cause

**Section 4: Survey, Geotechnical, and the Ground Beneath (4–5 paragraphs)**
- Geotechnical investigations — why borings matter more here than in most buildings
- High groundwater tables and their impact on basin construction
- Soil conditions and their effect on foundation design for heavy structures
- Rock: the word that makes project managers lose sleep
- The pre-design investigations that save millions during construction

**Conclusion (1–2 paragraphs):**
The civil engineer's work is the foundation — literally — for everything that follows. Their decisions about grades, pipe routing, and site organization are locked in early and expensive to change later.

**Next Chapter Teaser:**
But water doesn't treat itself inside open basins alone. It flows through buildings — and those buildings have to house complex mechanical equipment, withstand corrosive environments, and somehow function as workplaces for the operators who spend their careers inside them. That's where the architects and structural engineers enter the picture, and their challenges are unlike anything in conventional building design.

---

### Chapter 6: Buildings That Breathe Poison — Architecture and Structural
**~1,400 words**

**Opener (2–3 paragraphs):**
Analogy from submarine design — creating an enclosed environment that must manage extreme atmospheric conditions, house complex machinery, and remain habitable for the people who work inside. A wastewater treatment plant headworks or solids handling building faces similar constraints: corrosive gases, heavy vibration, and the need for humans to operate safely in conditions that are actively hostile to both equipment and people.

**Section 1: The Architect's Unusual Role (4–5 paragraphs)**
- Architecture on a treatment plant: function dominates form, but form still matters
- Building codes, occupancy classifications, and the H-occupancy question (hazardous)
- Ventilation as architecture: the building envelope is designed around air management
- Material selection in corrosive environments: why standard finishes fail within years
- The public-facing elements: administration buildings, lab spaces, and the growing trend of "showcase" treatment facilities

**Section 2: Structural Engineering for Liquid-Retaining Structures (4–5 paragraphs)**
- Designing tanks and basins: the structural challenges of holding millions of gallons
- ACI 350 — the code that governs environmental engineering concrete structures
- Crack control: why wastewater structures have stricter crack width limits than buildings
- Seismic design for liquid-retaining structures — sloshing loads and their unique behavior
- The structural engineer's relationship with the process engineer: form follows function, literally

**Section 3: Corrosion — The Silent Destroyer (4–5 paragraphs)**
- Hydrogen sulfide (H₂S): the gas that eats concrete and steel
- Coatings, liners, and material selection strategies
- FRP (fiberglass reinforced plastic), stainless steel, and specialty alloys
- The lifecycle cost argument: spending more upfront on corrosion resistance vs. replacing structures in 15 years
- What veterans know: the most expensive maintenance problems in wastewater plants are almost always corrosion-related

**Section 4: Expansion, Phasing, and Future-Proofing (4–5 paragraphs)**
- Designing for the 20-year capacity while building for the 10-year need
- Structural provisions for future expansion: stub-outs, reinforced walls, and empty basins
- The tension between budget constraints and long-term planning
- Demolition and rehabilitation of existing structures during plant upgrades
- The insider's view: the most elegant designs are the ones that make the next phase easy, not the ones that maximize today's efficiency

**Conclusion (1–2 paragraphs):**
The buildings on a treatment plant site are not conventional buildings. They're industrial vessels that happen to have roofs. The architects and structural engineers who design them operate in a specialized world that rewards experience over creativity.

**Next Chapter Teaser:**
Inside those buildings, an entirely different battle is being fought: the mechanical, electrical, plumbing, and fire protection systems that make the treatment process actually run. And the HVAC engineer — tasked with managing air in a building full of explosive and corrosive gases — has perhaps the most consequential job of anyone on the design team.

---

### Chapter 7: Guts and Wiring — MEPF and Process Mechanical
**~1,400 words**

**Opener (2–3 paragraphs):**
Analogy from the human nervous system — the body's organs (heart, lungs, liver) are impressive, but they're useless without the nervous system, blood vessels, and hormonal signals that coordinate them. In a treatment plant, the tanks and basins are the organs. The MEPF systems — mechanical, electrical, plumbing, and fire protection — are the nervous system. Without them, the plant is a collection of concrete boxes.

**Section 1: Process Mechanical — Pumps, Blowers, and Mixers (4–5 paragraphs)**
- The major mechanical equipment: pumps (influent, return, waste, effluent), blowers, mixers, scrapers
- Equipment selection: the interplay between process requirements, energy efficiency, and maintenance access
- Redundancy requirements: N+1 and why every critical system has a backup
- The specification process: performance specs vs. proprietary specs and the political implications
- Manufacturer relationships and the "or equal" clause — the behind-the-scenes negotiation

**Section 2: HVAC — Managing Air in a Hazardous Environment (4–5 paragraphs)**
- Ventilation classifications: confined spaces, hazardous atmospheres, and code requirements
- Odor control: chemical scrubbers, biofilters, carbon adsorption, and their HVAC implications
- The air change rate calculations that drive system sizing
- Energy implications: ventilating a headworks building is enormously expensive
- The HVAC engineer's nightmare: designing for corrosive air that destroys the very equipment meant to manage it

**Section 3: Electrical and Instrumentation (4–5 paragraphs)**
- Power distribution: medium voltage service, switchgear, motor control centers
- Standby power: generators and the critical requirement for continuous operation during outages
- Instrumentation and controls (I&C): the SCADA system as the plant's brain
- Variable frequency drives (VFDs) and their role in energy management
- The electrical engineer's challenge: hazardous area classifications and explosion-proof equipment requirements

**Section 4: Plumbing and Fire Protection — The Overlooked Essentials (4–5 paragraphs)**
- Process drains vs. sanitary drains vs. chemical drains — different systems, different codes
- Chemical feed systems: how treatment chemicals are stored, mixed, and injected
- Fire protection in buildings with hazardous gases and chemicals
- Potable water systems: backflow prevention and cross-connection control (the irony, again)
- The coordination nightmare: how MEP systems conflict in tight spaces and why BIM coordination matters enormously in these facilities

**Conclusion (1–2 paragraphs):**
MEPF systems are where the majority of the operational budget lives. The design decisions made here determine energy costs, maintenance burden, and operational flexibility for decades.

**Next Chapter Teaser:**
With the major disciplines covered, there's one more design conversation that cuts across all of them — and it's the one that generates the most heated debates in project meetings: the landscape architect's plan for what the neighbors will see, and the specialty consultants who handle everything from odor modeling to wetland mitigation. These are the voices that often arrive last but reshape the project most dramatically.

---

### Chapter 8: The Outer Ring — Landscape, Specialty Consultants, and the Public Face
**~1,300 words**

**Opener (2–3 paragraphs):**
Analogy from theater — the set designer, lighting director, and costume designer don't write the play, but they determine the audience's experience of it. In wastewater treatment plant design, the landscape architect, odor consultant, noise consultant, and other specialists don't design the treatment process — but they determine whether the community accepts or resents the facility.

**Section 1: Landscape Architecture — More Than Trees Around a Fence (4–5 paragraphs)**
- Visual screening and buffering: the first line of defense against community opposition
- Stormwater management integration: rain gardens, bioswales, and constructed wetlands
- Site security: balancing access control with aesthetics
- Native plantings, pollinator habitats, and the growing "green infrastructure" movement
- The landscape architect's real job: making an industrial facility look like it belongs in the community

**Section 2: Odor and Noise — The Invisible Neighbors (4–5 paragraphs)**
- Odor modeling: how consultants predict where smells will travel
- The odor control hierarchy: containment, treatment, and dispersion
- Noise studies: mechanical equipment, blowers, and the impact on adjacent properties
- Noise mitigation: enclosures, barriers, and equipment selection
- The insider perspective: odor complaints have killed more plant expansion projects than any technical problem

**Section 3: Specialty Consultants You Didn't Know You Needed (4–5 paragraphs)**
- Geotechnical engineers (revisited): foundation recommendations that reshape structural design
- Environmental scientists: wetland delineation, habitat assessment, and mitigation banking
- Traffic engineers: construction traffic, chemical delivery routes, and permanent access
- Commissioning agents: the independent reviewers who verify the design works as intended
- Surveying and mapping: the baseline data that everything builds on

**Section 4: The Bid Package — Turning Design into a Contract (4–5 paragraphs)**
- How construction documents are organized: divisions, specifications, and drawings
- The front-end documents: general conditions, supplementary conditions, and the contract form
- Bidding strategies: design-bid-build, design-build, and CM-at-risk
- Prequalification of contractors: why it matters more in wastewater than in most construction
- The moment the design team releases control: issuing for bid and holding their breath

**Conclusion (1–2 paragraphs):**
The design process is a symphony of specialists, each contributing a piece to a whole that must function as a unified system. When it works, it's invisible. When it doesn't, the problems compound across every discipline.

**Next Chapter Teaser:**
And then, after years of planning, funding, permitting, and design — after thousands of pages of drawings and specifications — a contractor shows up with heavy equipment and starts moving dirt. The construction phase is where the paper project becomes a physical reality, and where an entirely new set of challenges, personalities, and crises emerges. It starts with the thing every contractor dreads most: what they find underground.

---

## PART THREE: CONSTRUCTION
*Mud, Money, and the Making of Infrastructure*

---

### Chapter 9: Groundbreaking — Demolition, Excavation, and What Lies Beneath
**~1,300 words**

**Opener (2–3 paragraphs):**
Analogy from archaeology — how excavation is simultaneously destructive and revelatory. You can't see what's underground without digging, and what you find changes everything. In wastewater construction, the first major phase — demolition of existing structures and excavation for new ones — is where the project's assumptions meet reality, often violently.

**Section 1: Mobilization and the Contractor's World (4–5 paragraphs)**
- The preconstruction meeting: setting the tone for the entire project
- Mobilization: staging areas, temporary facilities, and the logistics of building inside an operating plant
- Maintaining treatment during construction: the constraint that makes wastewater construction uniquely difficult
- The bypass pumping plan: keeping sewage flowing while you tear apart the system that treats it
- The owner's representative and the resident engineer: the people who live on site for years

**Section 2: What You Find Underground (4–5 paragraphs)**
- Unknown utilities: the lines that aren't on any drawing
- Contaminated soil: when the site of a treatment plant has its own environmental problems
- Groundwater intrusion and dewatering operations
- Unexpected rock and the change order that follows
- The veteran's truth: every experienced project manager budgets for underground surprises. The only question is how big they'll be.

**Section 3: Concrete — The Material That Defines These Projects (4–5 paragraphs)**
- The sheer volume of concrete in a treatment plant: it dwarfs most building projects
- Formwork for basins: the specialized challenge of liquid-retaining concrete construction
- Waterstops, joint sealants, and the critical details that prevent leaks
- Concrete placement in extreme conditions: hot weather, cold weather, and mass concrete pours
- Quality control: testing, inspection, and the consequences of getting the mix wrong

**Section 4: The Schedule and the Weather (4–5 paragraphs)**
- Construction sequencing: why the order of operations matters more than in conventional building
- Phased construction in operating plants: building new while running old
- Weather delays and their cascading impact on treatment operations
- The critical path: the sequence of activities that determines the project's completion date
- The insider's perspective on schedule: the published schedule and the real schedule are rarely the same

**Conclusion (1–2 paragraphs):**
Groundbreaking is when the project gets real — physically, financially, and politically. The first six months of construction set the trajectory for everything that follows.

**Next Chapter Teaser:**
Once the concrete is poured and the structures rise, the project enters its most complex coordination phase: installing the mechanical, electrical, and process equipment that turns concrete shells into a functioning treatment system. This is where the dozens of subcontractors, hundreds of submittals, and thousands of coordination points either come together — or fall apart.

---

### Chapter 10: Iron in the Ground — Equipment Installation and Systems Integration
**~1,400 words**

**Opener (2–3 paragraphs):**
Analogy from organ transplant surgery — you can prepare the body perfectly, but the moment you begin installing the new organ, you're managing dozens of interconnected systems simultaneously, and the sequence and timing of each connection is critical. A wastewater treatment plant in the equipment installation phase is the same: the structures are the body, and the mechanical, electrical, and control systems are the organs being transplanted, one by one, in a precise order.

**Section 1: The Submittal Process — Paper Before Iron (4–5 paragraphs)**
- What submittals are and why they matter: manufacturer shop drawings, product data, and samples
- The review cycle: contractor → engineer → back to contractor, and the delays that accumulate
- Substitution requests: when the contractor proposes different equipment than specified
- Long-lead equipment: items that must be ordered months (sometimes a year) before installation
- The behind-the-scenes tension: every delayed submittal pushes the schedule, and blame flows in every direction

**Section 2: Mechanical Installation — Heavy Iron (4–5 paragraphs)**
- Setting major equipment: pumps, blowers, aerators, clarifier mechanisms
- Rigging and crane operations in tight spaces
- Alignment, grouting, and the precision required for rotating equipment
- Piping installation: field-run piping and the gap between drawings and reality
- The coordination challenge: when the structural opening is 2 inches too small for the equipment — who pays?

**Section 3: Electrical and Controls — Bringing the Plant to Life (4–5 paragraphs)**
- Medium voltage installation, transformer setting, and switchgear
- Cable pulling, termination, and the sheer volume of wire in a treatment plant
- SCADA programming and integration: making all the equipment talk to each other
- Generator installation and testing: the backup system that must work perfectly on the first try
- The controls integrator: the person who sits at the intersection of every system

**Section 4: Quality Control and the Paper Trail (4–5 paragraphs)**
- Inspection protocols: who watches what, and how disputes are documented
- RFIs (Requests for Information): the formal mechanism for resolving design ambiguities
- Change orders: how scope changes are priced, negotiated, and approved
- The daily log, photo documentation, and the project record
- The reality of construction administration: the design engineer's role doesn't end at bid — it transforms

**Conclusion (1–2 paragraphs):**
Equipment installation is the crescendo of the construction process. Every decision from every prior phase converges here, and the quality of coordination determines whether the plant starts up smoothly or painfully.

**Next Chapter Teaser:**
And then comes the moment of truth: startup and commissioning. The plant is built, the equipment is installed, the wires are connected — and someone has to turn it on. But "turning it on" for a biological treatment system isn't like flipping a light switch. It's more like waking up a living organism, and it can take months of patient coaxing before the plant performs as designed.

---

### Chapter 11: Startup — Waking the Organism
**~1,300 words**

**Opener (2–3 paragraphs):**
Analogy from sourdough bread making — you can build the perfect kitchen, buy the finest flour, install a beautiful oven, but none of it matters until you cultivate a healthy starter culture. And that culture has its own timeline, its own needs, and it cannot be rushed. Starting up a biological wastewater treatment plant is the same: you're cultivating a living ecosystem inside an engineered environment, and the biology doesn't care about your schedule.

**Section 1: Pre-Commissioning — Testing Before Flow (4–5 paragraphs)**
- Hydrostatic testing: filling tanks and checking for leaks
- Electrical testing: megger tests, relay calibration, and functional testing of every circuit
- Mechanical run-in testing: operating equipment without process water
- Alarm and safety system verification
- The punch list: the hundreds of small deficiencies that must be resolved before startup

**Section 2: Wet Commissioning — Introducing Flow (4–5 paragraphs)**
- The first flow through the plant: a carefully managed event
- Seeding the biological process: introducing microorganisms and feeding them
- The ramp-up period: gradually increasing flow and load over weeks or months
- Process tuning: adjusting aeration, chemical feed rates, and return sludge rates
- Why experienced operators are essential during commissioning — design engineers can design a plant, but operators bring it to life

**Section 3: Performance Testing — Proving the Design (4–5 paragraphs)**
- The performance test protocol: demonstrating the plant meets permit and design requirements
- Duration and conditions: typically 30 days of continuous compliant operation
- What happens when the plant doesn't meet performance: troubleshooting, finger-pointing, and resolution
- The engineer's warranty period and the contractor's correction period
- The handoff: transitioning from construction team to operations team

**Section 4: Training and the Human Element (4–5 paragraphs)**
- Operator training: the most underfunded and undervalued part of the project
- O&M manuals: the encyclopedic documents that nobody reads until something breaks
- Staffing transitions: when the old plant's operators must learn an entirely new system
- The emotional dimension: operators who've run a plant for 20 years watching it be demolished
- The veteran's perspective: the best-designed plant in the world fails if the operators aren't prepared

**Conclusion (1–2 paragraphs):**
Startup is the project's final exam — and unlike school, you can't cram for it. The months of patient biological cultivation and system tuning are the difference between a plant that works and one that limps along for years.

**Next Chapter Teaser:**
But the end of construction isn't really the end of anything. It's the beginning of a 30-year operational life, a closeout process that takes far longer than anyone expects, and a reckoning with whether the project actually delivered what was promised. The aftermath of a wastewater project is where reputations are made — or quietly destroyed.

---

## PART FOUR: AFTERMATH
*What Happens After the Ribbon Is Cut*

---

### Chapter 12: Closeout — The Longest Goodbye
**~1,300 words**

**Opener (2–3 paragraphs):**
Analogy from divorce proceedings — the decision to separate is the dramatic moment, but the actual process of untangling shared assets, resolving disputes, and finalizing paperwork takes far longer and is far more exhausting than anyone anticipates. Construction closeout has the same quality: the ribbon is cut, the politicians take credit, and then the project team spends another 12–18 months resolving the unglamorous details.

**Section 1: Substantial Completion vs. Final Completion (4–5 paragraphs)**
- The legal and contractual distinction between these two milestones
- The punch list process: systematic identification and resolution of deficiencies
- Retainage: the money held back until the contractor finishes everything
- The warranty period: what's covered, what's not, and the disputes that arise
- The insider's perspective: substantial completion is a negotiation, not a date on a calendar

**Section 2: Financial Closeout — Where the Bodies Are Buried (4–5 paragraphs)**
- Final change order reconciliation
- Allowance and contingency accounting: what was spent, what wasn't
- Final pay applications and the last retainage release
- Funding agency closeout requirements: the paperwork that rivals the construction in complexity
- Audits: when the funding source wants to verify every dollar — and why this matters years later

**Section 3: As-Built Drawings and Record Documents (4–5 paragraphs)**
- The as-built drawing process: documenting what was actually built vs. what was designed
- O&M manuals, spare parts lists, and warranty documentation
- The digital handoff: CAD files, SCADA programming, and the data the owner needs to maintain the plant
- The reality: as-builts are often inaccurate, O&M manuals are often generic, and the owner inherits the consequences
- Why experienced owners hire a commissioning agent to verify the record documents

**Section 4: The Contractor's Departure and What Remains (4–5 paragraphs)**
- Site restoration and demobilization
- The lingering items: disputed change orders, uncompleted punch list items, warranty claims
- The relationships that endure — or don't — between owner, engineer, and contractor
- The often-overlooked transition: from a site with 100 construction workers to a plant with 10 operators
- What the community notices: the noise stops, the trucks disappear, and a quiet facility begins its decades-long mission

**Conclusion (1–2 paragraphs):**
Closeout lacks drama but requires discipline. The projects that close out cleanly are the ones that operate successfully — because the documentation and resolution that happens now determines the owner's ability to maintain, repair, and eventually expand the facility.

**Next Chapter Teaser:**
With the construction team gone and the operators in charge, a different kind of story begins — the operational life of the plant. And the question nobody asked during design becomes the most important question of all: did we actually build what this community needed? The answer reveals truths about how we plan, fund, and execute public infrastructure that extend far beyond wastewater.

---

### Chapter 13: The Long View — Operations, Legacy, and What We Get Wrong
**~1,300 words**

**Opener (2–3 paragraphs):**
Analogy from cathedral building in medieval Europe — the architects and masons who began the work knew they would never see the finished cathedral. They were building for generations beyond their own. Wastewater treatment plants aren't cathedrals, but they share this quality: the decisions made during design and construction play out over 30–50 years, long after the project team has moved on. The question is whether those decisions were made with the long view in mind.

**Section 1: The First Five Years — Shakedown and Reality (4–5 paragraphs)**
- Equipment failures and warranty claims: what breaks first
- Operational optimization: the tweaking that happens after the engineers leave
- Energy costs: when the actual utility bills arrive vs. the design projections
- Staffing and training gaps that become apparent under real operating conditions
- The gap between design intent and operational reality — and who's responsible for closing it

**Section 2: The 20-Year Horizon — What Wears Out and What Evolves (4–5 paragraphs)**
- Equipment lifecycle: what needs replacement at 10, 15, and 20 years
- Regulatory evolution: when new permit limits exceed the plant's design capability
- Technology changes: how the industry's tools evolve faster than the infrastructure
- The capital improvement plan: how owners budget for the plant's ongoing needs
- The uncomfortable truth: most municipalities don't adequately fund ongoing maintenance, and the cycle of neglect begins again

**Section 3: What We Consistently Get Wrong (4–5 paragraphs)**
- Underestimating lifecycle costs in favor of low construction bids
- Designing for today's regulations instead of tomorrow's
- Undervaluing operator input during design
- The "build and forget" mentality in public infrastructure
- The systemic problem: political cycles are 2–4 years, but infrastructure cycles are 30–50 years

**Section 4: What Getting It Right Looks Like (4–5 paragraphs)**
- Communities that invested in resilient, adaptable designs
- The role of asset management programs
- Operator-driven design: plants that were shaped by the people who run them
- Water reuse and resource recovery: the future of wastewater treatment
- The quiet pride of the work: protecting public health, every day, without recognition

**Conclusion (1–2 paragraphs):**
A wastewater treatment plant is not a monument to the people who built it. It's a promise to the community it serves — a promise that the water leaving the facility is safe, that the environment is protected, and that the infrastructure will endure. Keeping that promise requires not just good engineering, but sustained public investment, operational excellence, and the political will to maintain what we've built.

**Final Closing (in lieu of "Next Chapter Teaser"):**
A brief, reflective paragraph — something about the reader now having the vocabulary and understanding to participate in these conversations, whether they're a municipal official, a citizen, an engineering student, or simply someone who turns on the tap and wonders where the water goes after it swirls down the drain. The goal was never to make the reader an engineer — it was to make them an informed participant in one of the most important, and least visible, investments a community can make.

---

## APPENDICES (Optional — brief descriptions)

- **Appendix A: Glossary of Terms** — Key technical vocabulary defined in plain language
- **Appendix B: Typical Project Timeline** — A visual timeline showing the major phases and their typical durations (planning through closeout)
- **Appendix C: Funding Source Comparison Table** — SRF, USDA, WIFIA, municipal bonds compared side by side
- **Appendix D: Key Regulations and Codes** — A reference list of the major regulations mentioned throughout the book
- **Appendix E: Further Reading** — Resources for readers who want to go deeper on specific topics

---

## STRUCTURAL NOTES

**Chapter Structure Recap (each chapter follows this pattern):**
1. **Opener** (2–3 paragraphs): Analogy from outside the field that illuminates the chapter's topic
2. **Body** (3–4 sections × 4–5 paragraphs each): Substantive content mixing technical explanation, insider perspective, and narrative color
3. **Conclusion** (1–2 paragraphs): Synthesis of the chapter's themes
4. **Next Chapter Teaser** (2–3 sentences): Forward-looking hook with tension

**Target Word Counts:**
- Ideal: 1,200–1,400 words per chapter
- Maximum: 2,000 words per chapter
- 13 chapters × ~1,300 words = ~16,900 words total manuscript
- With appendices: ~19,000–20,000 words

**Tone:**
- New Yorker-style narrative nonfiction applied to infrastructure
- Insider knowledge without jargon overload
- Respects the reader's intelligence while assuming no prior technical knowledge
- Dry humor where appropriate — the material lends itself to irony
- The "10-project veteran" perspective woven throughout: what you learn by repetition that no textbook teaches
