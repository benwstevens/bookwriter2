Create an outline by chapter of a book that's about "developing" a wastewater treatment plan. 
Part 1 is about the history, state of the technology, political background, and new yorker style color. Explain why they happen and what someone would know if they'd done 10 of these about the behind the scenes. Also discuss the timelines and how they related to funding approvals. 
Part 2 is about the design process. Divide it however you want but give me some on the basics of how it works; some on the unique aspects that have to be considered by all of the consultants (civil, landscape, arch, structural, MEPF, and any specialties). 
Part 3 is about the construction process. 
And Part 4 is about the aftermath of construction, parting thoughts, etc. 
Chapters should be not more than 2000 words. 1200-1400 words is ideal. 
A chapter should be structured as follows: o 2-3 paragraph opener with an analogy about the topic (ideally an analogy from a different field that helps it make sense, not a “war story” directly related to the topic. o Then 3-4 sections of 4-5 paragraphs eachs o Then a 1-2 paragraph conclusion o 
And finally, an “in the next chapter” teaser of a few sentences about what’s coming next. This should have a note of tension that pulls the reader forward.